// Empty JS for your own code to be here
var dragleave="";
	var sampleData={};
function allowDrop(ev) {
    ev.preventDefault();
       ev.target.innerHTML="";
}

function dragLeave(ev) {

    ev.preventDefault();
    ev.target.innerHTML=document.getElementById(dragleave).innerHTML;

}



function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
	    // console.log(ev.target);
	    $(".list-unstyled li").css("display","block");
    ev.preventDefault();
      // console.log(ev.target);
    var data = ev.dataTransfer.getData("text");
        // console.log(document.getElementById(data));
    ev.target.innerHTML=document.getElementById(data).innerHTML;
    
dragleave=data;
	$(".list-unstyled #"+data).css("display","none");
	// console.log($("#"+data).html());	

	if($("#"+data).html())
	{
	sampleData={"key":$("#"+data+" .key").html(),"value":$("#"+data+" .value").html()};
	}

}


$(document).on("click","#button-drop",function(){
	
localStorage.setItem('id',$('#uid').val());
localStorage.setItem('fname',$('#ufname').val());
localStorage.setItem('lname',$('#ulname').val());
$('.hidden-content-first').hide();
$('.hidden-content-second').show();
	$.ajax({
        type: "GET",
		dataType: "json",
        url: "https://reqres.in/api/users?page=2",
        success: function(result) {
			
			 for(i=0;i<result.data.length;i++)
			{
				
				$('<li class="list-item" id="drag '+i+' " draggable="true" ondragstart="drag(event)"/>').html("<span class='key'> "+result.data[i].id+" </span> <span class='value'> "+result.data[i].first_name+" </span>").appendTo('ul.list-unstyled');
			
			} 
			console.log(result);
        },
        error: function(result) {
            alert('error');
			console.log(result);
        }
    });


}); 

$(document).on("click","#button-req",function(){
	
var rid = localStorage.getItem('id');
var rfname = localStorage.getItem('fname');
var rlname = localStorage.getItem('lname');
sampleData.id=rid;
sampleData.fname=rfname;
sampleData.lname=rlname;
	/*$.ajax({
        type: "GET",
		dataType: "json",
        url: "https://reqres.in/api/users?page=2",
        success: function(result) {
			
			$("#myModal").modal('show');
			 for(i=0;i<result.data.length;i++)
			{
				
				$('#myModal p').html("<span class='key'>Id = "+result.data[i].id+"</span> <span class='value'> First Name = "+result.data[i].first_name+"</span>");
			
			} 
			console.log(result);
        },
        error: function(result) {
            alert('error');
			console.log(result);
        }
    });*/
	
	//AJAX Request Post form
		$.ajax({
        type: "POST",
		data:sampleData,
		dataType: "json",
        url: "https://reqres.in/api/users",
        success: function(result) {
			
			$("#myModal").modal('show');
			 $('#myModal p').html("<span class='key'>Key = "+result.key+"</span> <span class='value'> Value = "+result.value+"</span>"); 
			
        },
        error: function(result) {
            alert('error');
			console.log(result);
        }
    });


}); 


$(document).on('change', '.show-radio', function() {
    if ($(this).is(':checked'))
    {
      $('.hidden-content-first').show();
    }
	
	else
	{
		$('.hidden-content-first').hide();
	}
});

$(document).ready(function(){
	$("#myModal").modal('hide');
	var jsonData = {
    "name": "morpheus",
    "job": "leader"
};
	$('.main-container').load('loading.html .load-this');
	 	// AJAX Request Get form
		$.ajax({
        type: "GET",
		dataType: "json",
        url: "https://reqres.in/api/users?page=2",
        success: function(result) {
			
			 for(i=0;i<result.data.length;i++)
			{
				
				$('<option value='+result.data[i].id+'>'+result.data[i].id+'</option>').appendTo('#uid');
				$('<option value='+result.data[i].first_name+'>'+result.data[i].first_name+'</option>').appendTo('#ufname');
				$('<option value='+result.data[i].last_name+'>'+result.data[i].last_name+'</option>').appendTo('#ulname');
			
			} 
			console.log(result);
        },
        error: function(result) {
            alert('error');
			console.log(result);
        }
    });
	
	
	
});
