var droppable = "";

$(document).ready(function(){

	$('.main-container').load('practice.html');


	$.ajax ({

			url : "https://reqres.in/api/users?page=2",
			type : "GET",
			dataType : "json",

			success :function(result){
				console.log(result);
				for(i=0;i<result.data.length;i++){

					$("#uid").append($("<option/>",{

						value : result.data[i].id,
						text : result.data[i].id


					}));



				}

			},
			error: function(result){

			}
	});

	$.ajax ({

		url : "https://reqres.in/api/users?page=2",
		type : "GET",
		dataType : "json",

		success :function(result){

			for(i=0;i<result.data.length;i++){

				$("#fname").append($("<option/>",{

					value : result.data[i].first_name,
					text : result.data[i].first_name

				}))
			}

		},
		error :function(result){

		}


	});

	$.ajax({

		url:"https://reqres.in/api/users?page=2",
		type:"GET",
		dataType:"json",

		success:function(result){

			for(i=0;i<result.data.length;i++){

				$("#lastname").append($("<option/>",{

					value : result.data[i].last_name,
					text : result.data[i].last_name

				}))
			}

		},
		error:function(){

		}
	})
	

});

var droppable = "";




function drop(event){

	event.preventDefault();
    var data = event.dataTransfer.getData("text");
     event.target.innerHTML = document.getElementById(data).innerHTML;

     $('#testing #'+data).css("display","none");

     if(droppable != ""){
     		 $('#testing #'+droppable).css("display","block");
     }
		droppable = data;

}

function allowDrop(event){
	event.preventDefault();
}

function drag(event){

	event.dataTransfer.setData("text", event.target.id);
}

$(document).on("click",'#getQuote',function(){

	$(".firstSection").hide();
	$(".secondSection").hide();
	$(".thirdSection").show();



	$.ajax ({

		type :"GET",
		url:"https://reqres.in/api/users?page=2",
		dataType:"json",

		success:function(result){

			for(i=0;i<result.data.length;i++){
				// $('<li class="list-item"  draggable="true" id="drag'+i+'" ondragstart="drag(event)"/>').html('<span class="className"> '+result.data[i].id+'</span> <span class="className"> '+result.data[i].first_name+' </span>').appendTo('ul.list-unstyled');
				$('<li class="list-item" style="border:1px solid blue" ondragstart="drag(event)"  id="drag'+i+'" draggable="true"/>').html('<div> '+result.data[i].id+ " "+result.data[i].first_name+'</div>').appendTo('ul.list-unstyled');
			}

		},
		failure:function(result){
					// 

		}

	})

});

$(document).on('change','.show',function()
{
	if($(this).is(":checked")){

		$('.IntialContents').show();

	}
	else{

		$('$.IntialContents').hide();
	}


});


