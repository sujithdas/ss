$(document).ready(function(){


	$(".main-container").load("practice3.html");

	$.ajax({

		type:"GET",
		url:"https://reqres.in/api/users?page=2",
		dataType:"json",

		success:function(result){

			for(i=0;i<result.data.length;i++){

				$("#uid").append($("<option/>",{


					value:result.data[i].id,
					text:result.data[i].id
				}))
			}


		},
		failure:function(result){

		}


	});

	$.ajax({

		url:"https://reqres.in/api/users?page=2",
		type:"GET",
		dataType:"json",

		success:function(result){

			for(i=0;i<result.data.length;i++){

				$("#fname").append($("<option/>",{

					value:result.data[i].first_name,
					text:result.data[i].first_name

				}))
			}

		},

		failure:function(result){

		}

	})

	$.ajax({

			url:"https://reqres.in/api/users?page=2",
			type:"GET",
			dataType:"json",

			success:function(result){

				for(i=0;i<result.data.length;i++){

					$("#lname").append($("<option/>",

					{
							value:result.data[i].last_name,
							text: result.data[i].last_name

					}))

					
				}

			},
			failure:function(result){


			}

	})




});

$(document).on('change','.show',function(){

	if($(this).is(":checked")){

		$(".firstSection").show();
		$(".secondSection").show();

	}
	else{
		$(".firstSection").hide();
		$(".secondSection").hide();
	}


});


function drag(event){
	event.dataTransfer.setData("text", event.target.id);
}

var item =""

function drop(event){
	event.preventDefault();
	var data = event.dataTransfer.getData("text");
	event.target.innerHTML = document.getElementById(data).innerHTML;

	$('#testing #'+data).css('display','none');

	if(item != ""){
		$('#testing #'+item).css('display','block');
	}
		item = data;


}

function allowdrop(event){
	event.preventDefault();

}





$(document).on('click',"#getQuote",function(){

	$(".firstSection").hide();
	$(".secondSection").hide();
	$(".thirdSection").show();
	$("#fourthSection").show();

	$.ajax({

		url:"https://reqres.in/api/users?page=2",
		type:"GET",
		contentType:"json",


		success:function(result){

			for(i=0;i<result.data.length;i++){

				$('<li class="list-item" style="border:1px solid blue;" id="drag'+i+'" draggable="true" ondragstart="drag(event)"/>').html('<div>' +result.data[i].id+ " " +result.data[i].first_name+ '</div>').appendTo('ul.list-unstyled');  

			}

		},
		failure:function(result){

		}


	})

	localStorage.setItem('id',$('#uid').val());
	localStorage.setItem('fiName',$('#fname').val());
	localStorage.setItem('laname',$('#lname').val());

	


});

$(document).on('click','#upload',function(){

		var first = localStorage.getItem('fiName');
		var second= localStorage.getItem('lname');
		var idzz  = localStorage.getItem('id');

		var object = {};
		object.id = idzz;
		object.first = first;
		object.second = second;

		$.ajax({

				url:"https://reqres.in/api/users",
				type:"POST",
				dataType:"json",
				data:"object",

				success:function(result){

					$("#myModal").modal('show');
			 $('#myModal p').html("<span class='key'>Key = "+result.key+"</span> <span class='value'> Value = "+result.value+"</span>"); 

				},
				failure:function(result){

				}

		})

})






