$(document).ready(function(){

	$('.main-container').load('practice4.html');

	$.ajax({

		url:"https://reqres.in/api/users?page=2",
		type:"GET",
		dataType:"json",

		success:function(result){

			for(i=0;i<result.data.length;i++){

				$('#uid').append($('<option/>',{

					value:result.data[i].id,
					text: result.data[i].id

				}))
			}

		},
		failure:function(result){

		}
	})

	$.ajax({

			url:"https://reqres.in/api/users?page=2",
			type:"GET",
			dataType:"json",

			success:function(result){

				for(i=0;i<result.data.length;i++){
					$('#fname').append($('<option/>',{

						type:result.data[i].first_name,
						text:result.data[i].first_name
					}))
				}
			},
			failure:function(result){

			}

	})


	$.ajax({
				url:"https://reqres.in/api/users?page=2",
				type:"GET",
				dataType:"json",

				success:function(result){
						for(i=0;i<result.data.length;i++){
							$("#sname").append($('<option/>',{

								type:result.data[i].last_name,
								text:result.data[i].last_name
							}))
						}
				},
				failure:function(result){

				}		
	})


});

$(document).on('change','.show',function(){

	if($(this).is(':checked'))
{
		$('.firstSection').show();
		$('.secondSection').show();
}
else{
		$('.firstSection').hide();
		$('.secondSection').hide();
}
		
});


$(document).on('click','#getQuote',function(){

		$('.firstSection').hide();
		$('.secondSection').hide();


		localStorage.setItem('id',$('#uid').val());
		localStorage.setItem('fname',$('#fname').val());
		localStorage.setItem('lname',$('#sname').val());

		$.ajax({

			url:"https://reqres.in/api/users?page=2",
			type:"GET",
			dataType:"json",

			success:function(result){

				for(i=0;i<result.data.length;i++){

					$('<li id="drag'+i+'" style="border:1px solid blue;" draggable="true" ondragstart="drag(event)"/>').html('<div>' +result.data[i].id+ " " +result.data[i].first_name+ '</div>').appendTo('ul.list-unstyled');
				}

			},
			failure:function(result){

			}
		})

})

function drag(event){

	event.dataTransfer.setData('text',event.target.id)
}

function drop(event){
		event.preventDefault();
}

var droppable = "";

function allowdrop(event){
	event.preventDefault();
	var data = event.dataTransfer.getData('text');
	event.target.innerHTML = document.getElementById(data).innerHTML;

	$("#testing #"+data).css('display','none');

	if(droppable != ""){

		$("#testing #" +droppable).css('display','block');
	}

	droppable = data;

}


$(document).on('click','#upload',function(){

	var object = {}

		var idz = localStorage.getItem('id')
		var fname = localStorage.getItem('fname');
		var lname = localStorage.getItem('lname');

		object.idz = idz;
		object.fname = fname;
		object.lname = lname;


		$.ajax({

				url:"https://reqres.in/api/users",
				data: object,
				type:"POST",
				dataType:"json",

				success:function(result){

					//$('#modal').modal('show');
					//$('<p>' +result)

				},
				failure:function(result){

				}

		})

})







