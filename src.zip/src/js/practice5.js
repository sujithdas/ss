$(document).ready(function(){

	$('.main-container').load('practice5.html')

	$.ajax({

			url:"https://reqres.in/api/users?page=2",
			type:"GET",
			dataType:"json",


			success:function(result){

				for(i=0;i<result.data.length;i++){

					$('#uid').append($('<option/>',{

							text:result.data[i].id,
							value:result.data[i].id
					}))
				}

			},
			failure:function(result){

			}

	})

	$.ajax({


			url:"https://reqres.in/api/users?page=2",
			type:"GET",
			dataType:"json",

			success:function(result){

				for(i=0;i<result.data.length;i++){

					$('#fname').append($('<option/>',{

						text:result.data[i].first_name,
						value:result.data[i].first_name
					}))
				}

			},
			failure:function(result){

			}
	})

	$.ajax({

		url:"https://reqres.in/api/users?page=2",
		type:"GET",
		dataType:"json",

		success:function(result){

			for(i=0;i<result.data.length;i++)
					{

						$('#lname').append($('<option/>',{

							text:result.data[i].last_name,
							value:result.data[i].last_name
						}))

						
					}
		},
		failure:function(result){

		}
	})


});

$(document).on('change','.show',function(){


	if($(this).is(":checked")){
			$('.firstSection').show();
			$('.secondSection').show();
		}
	else{

			$('.firstSection').hide();
			$('.secondSection').hide();
			$(".fourthSection").hide();
	}

})

$(document).on('click','#getQuote',function(){

			$('.firstSection').hide();
			$('.secondSection').hide();
			$('.thirdSection').show();
			$('.fourthSection').show();
			
			localStorage.setItem('id',$('#uid').val());
			localStorage.setItem('fname',$("#fname").val());
			localStorage.setItem('lname',$("#lname").val());


			$.ajax({


				url:"https://reqres.in/api/users?page=2",
				type:"GET",
				contentType:"json",

				success:function(result){


					for(i=0;i<result.data.length;i++){

						$('<li draggable="true" id="drag'+i+'" ondragstart="drag(event)" style="border:1px solid blue" />').html('<div>' +result.data[i].id+ " " +result.data[i].first_name).appendTo('ul.list-unstyled');
					}

				},
				failure:function(result){

				}
			})

})


function drag(event){

	event.dataTransfer.setData('text',event.target.id);

}

function dragover(event){
	event.preventDefault();
	

}

var droppable =""

function drop(event){

	event.preventDefault();
	var data = event.dataTransfer.getData('text');
	event.target.innerHTML = document.getElementById(data).innerHTML;

	$('#testing #'+data).css('display','none')

	if(droppable != ""){
		$("#testing #"+droppable).css('display','block')
	}

	droppable = data;
}


$(document).on('click','#upload',function(){

	var idz = localStorage.getItem('id');
	var fname = localStorage.getItem('fname');
	var lname = localStorage.getItem('lname');

	var object = {};

	object.id= idz;
	object.fname = fname;
	object.lname = lname;

	$.ajax({

		url:"https://reqres.in/api/users",
		data:object,
		type:"POST",
		dataType:"json",

		success:function(result){

			$('#modal').modal('show');

		},

		failure:function(result){

		}




	})



});

function isNumber(event){

	var code = event.keyCode;

	if(code>48 && code<57){

		return true;
	}
	return false;
}

















