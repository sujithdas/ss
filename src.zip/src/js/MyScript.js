
$(document).ready(function(){
	$('.main-container').load('MyLoading.html .load-this');

	var urls = ['https://reqres.in/api/users?page=2', 'https://reqres.in/api/users?page=2','https://reqres.in/api/users?page=2'];

	$.when(getData(urls[0]), getData(urls[1]), getData(urls[2])) 
	.then( sucesscallback, failurecallback );

});

$(document).on('change', '.show-radio',function()
{
	if ($(this).is(":checked"))
	{
		$('.hidden-content').show();
	}
	else
	{
		$('.hidden-content').hide();
	}

});

function getData(url)
{
	return $.ajax({
		url : url,
		type : "GET",
		dataType : "json"
	});
};

function sucesscallback(data1,data2,data3)
{
	console.log(data1[0].data[0].first_name);
	for(i=0;i<data1[0].data.length;i++){
		$("#uid").append($("<option/>",{
			value : data1[0].data[i].id,
			text : data1[0].data[i].id
		}));
	}
//$("#select0").append("<option value="+data1[0][0].first_name+">"+data1[0][0].first_name+"</option>");
for(i=0;i<data1[0].data.length;i++){
	$("#fname").append($("<option/>",{
		value : data1[0].data[i].first_name,
		text : data1[0].data[i].first_name
	}));
}
for(i=0;i<data1[0].data.length;i++){
	$("#lname").append($("<option/>",{
		value : data1[0].data[i].last_name,
		text : data1[0].data[i].last_name,
	}));
}

};

function failurecallback(data1,data2,data3){

}

$(document).on("click","#sendButton",function(){

	var rid    = localStorage.getItem('id');
	var rfname = localStorage.getItem('fname');
	var rlname = localStorage.getItem('lname');
	$('.hidden-content').hide();
	$('.hidden-second').show();
	$.ajax({
        type: "GET",
		dataType: "json",
        url: "https://reqres.in/api/users?page=2",
        success: function(result) {
			
			 for(i=0;i<result.data.length;i++)
			{
				
				$('<li class="list-item" id="drag'+i+'"draggable="true" ondragstart="drag(event)"/>').html("<span class='key'>"+result.data[i].id+"</span> <span class='value'>"+result.data[i].first_name+"</span>").appendTo('ul.list-unstyled');
			
			} 
			console.log(result);
        },
        error: function(result) {
            alert('error');
			console.log(result);
        }
    });

});

function drop(ev) {
	    // console.log(ev.target);
	    $(".list-unstyled li").css("display","block");
    ev.preventDefault();
      // console.log(ev.target);
    var data = ev.dataTransfer.getData("text");
        // console.log(document.getElementById(data));
    ev.target.innerHTML=document.getElementById(data).innerHTML;
    
dragleave=data;
	$(".list-unstyled #"+data).css("display","none");
	// console.log($("#"+data).html());	

	if($("#"+data).html())
	{
	sampleData={"key":$("#"+data+" .key").html(),"value":$("#"+data+" .value").html()};
	}

}

function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}

function allowDrop(ev){
	 ev.preventDefault();
     ev.target.innerHTML="";
}

function dragLeave(ev){
	ev.preventDefault();
    ev.target.innerHTML=document.getElementById(dragleave).innerHTML;

}
